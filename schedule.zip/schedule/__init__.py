from schedule.application import application
from schedule import routes